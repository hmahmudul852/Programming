//problem 3:WAP to find GCD of two itegers
#include<stdio.h>
int GCD(int x,int y){
	int m = x%y;
	if(m==0)
		return y;
	return GCD(y,m);
}
int main(){
	int a,b,x,y,z;
	printf("\nEnter first number:");
	scanf("%d",&a);
	printf("\nEnter second number:");
	scanf("%d",&b);
	if(a>b){
		x=a;
		y=b;
	}
	else
	{
		y=a;
		x=b;
	}
	z = GCD(x,y);
	printf("GCD is %d\n",z);
	return 0;
}