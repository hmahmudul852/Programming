//Problem 8: WAP to find the union and intersection of two sets of integers.
#include<stdio.h>
int main(){
	int A[100],B[100];
	int i,j,n,m,count=0;
	printf("Enter size of Set A:");
	scanf("%d" ,&m);
	printf("Enter A-set integers:\n");
	for(i=0;i<m;i++)
		scanf("%d",&A[i]);
	printf("Enter size of Set B:");
	scanf("%d" ,&n);
	printf("Enter B-set integers:\n");
	for(i=0;i<n;i++)
		scanf("%d",&B[i]);
	printf("A = ");
	for(i=0;i<m;i++)
		printf("%d ",A[i]);
	printf("\n");
	printf("B = ");
	for(i=0;i<n;i++)
		printf("%d ",B[i]);
	printf("\n");
	printf("INTERSEC: ");
	for(i=0; i<m; i++)
	{
		for(j=0; j<n; j++)
		{
			if(A[i]==B[j])
			{
				printf("%d ",A[i]);
				count++;
			}
		}
	}
	if(count==0)
		printf("Empty set");
	printf("\n");

	printf("UNION: ");
	for(j=0; j<n; j++)
	{
		for(i=0; i<n; i++)
		{
			if(B[j]==A[i])
			{
				B[j]='c';
			}
		}
	}
	for(i=0; i<m; i++)
	{
		printf("%d ",A[i]);
	}
	for(i=0; i<n; i++)
	{
		if(B[i]!='c')
		printf("%d ",B[i]);
	}
	
	
	return 0;
}