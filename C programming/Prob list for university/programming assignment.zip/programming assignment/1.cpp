//problem 1:WAP to check whether a given integer is prime or not
#include<stdio.h>
int main(){
  int num,i,count=0;
  printf("\nEnter a number:");
  scanf("%d",&num);
  for(i=2;i<=num;i++){
     if(num%i==0)
		 count++;
  }
  if(count==2)
	  printf("%d is a prime number\n" , num);
  else
	  printf("%d is not a prime number\n" , num);
  
  return 0;
}