//problem 4: WAP to find LCM of two itegers
#include<stdio.h>
int main(){
  int num1,num2,x,gcd,lcm,product;
  printf("\nEnter first number:");
  scanf("%d",&num1);
  printf("\nEnter second number:");
  scanf("%d",&num2);
  
  if(num1 < num2)
     x = num1;
  else
	x = num2;
  for(;x>=1;x--){
	  if(num1%x==0 && num2%x==0){
		gcd=x;
        break;
      }
  }
  product = num1 * num2;
  lcm = product/gcd;  
	  
  printf("\nLCM of %d and %d is = %d \n\n" , num1,num2,lcm);
  
  return 0;
}