//Problem 12: WAP to fnd AND,OR,XOR from two different length bit strings. 
#include<stdio.h>
#define S 50
int main(){
	int A[S],B[S];
	int i,j,n,m,diff;
	printf("Enter size of first string:");
	scanf("%d", &n);
	printf("Enter size of second string:");
	scanf("%d", &m);
	if(m>n)
		diff = m-n;
	else
		diff = (m-n)*(-1);
	printf("difference of both string length=%d\n" ,diff);

	if(n>m){
		int max=n;
		printf("A = ");
		for(i=0;i<n;i++)
			scanf("%d" ,&A[i]);
		printf("B = ");
		for(i=0;i<diff;i++){
			B[i] = 0;
			printf("%d\n" ,B[i]);
		}
		for(i=diff+1;i<=n;i++)
			scanf("%d" ,&B[i]);
		printf("AND:");
		printf("\n");
		for(i=0,j=0;i<n,j<n;i++,j++){
			if(A[i]==1 && B[j]==1)
				printf("1 ");
			else if(A[i]==1 && B[j]==0)
				printf("0 ");
			else if(A[i]==0 && B[j]==1)
				printf("0 ");
			else if(A[i]==0 && B[j]==0)
				printf("0 ");
		}
		printf("\n");
		printf("OR:");
		printf("\n");
		for(i=0,j=0;i<n,j<n;i++,j++){
			if(A[i]==1 && B[j]==1)
				printf("1 ");
			else if(A[i]==1 && B[j]==0)
				printf("1 ");
			else if(A[i]==0 && B[j]==1)
				printf("1 ");
			else if(A[i]==0 && B[j]==0)
				printf("0 ");
		}	
		printf("\n");
		printf("XOR:");
		printf("\n");
		for(i=0,j=0;i<max,j<max;i++,j++){
			if(A[i]==1 && B[j]==1)
				printf("0 ");
			else if(A[i]==1 && B[j]==0)
				printf("1 ");
			else if(A[i]==0 && B[j]==1)
				printf("1 ");
			else if(A[i]==0 && B[j]==0)
				printf("0 ");
		}	

	}
	return 0;
}