//Problem 11: WAP to fnd AND,OR,XOR from two same length bit strings. 
#include<stdio.h>
#define S 50
int main(){
	int A[S],B[S];
	int i,j,n;
	printf("Enter size of two string:");
	scanf("%d", &n);
	printf("A = ");
	for(i=0;i<n;i++)
		scanf("%d" ,&A[i]);
	printf("B = ");
	for(i=0;i<n;i++)
		scanf("%d" ,&B[i]);
	printf("AND:");
	printf("\n");
	for(i=0,j=0;i<n,j<n;i++,j++){
		if(A[i]==1 && B[j]==1)
			printf("1 ");
		else if(A[i]==1 && B[j]==0)
			printf("0 ");
		else if(A[i]==0 && B[j]==1)
			printf("0 ");
		else if(A[i]==0 && B[j]==0)
			printf("0 ");
	}
	printf("\n");
	printf("OR:");
	printf("\n");
	for(i=0,j=0;i<n,j<n;i++,j++){
		if(A[i]==1 && B[j]==1)
			printf("1 ");
		else if(A[i]==1 && B[j]==0)
			printf("1 ");
		else if(A[i]==0 && B[j]==1)
			printf("1 ");
		else if(A[i]==0 && B[j]==0)
			printf("0 ");
	}	
	printf("\n");
	printf("XOR:");
	printf("\n");
	for(i=0,j=0;i<n,j<n;i++,j++){
		if(A[i]==1 && B[j]==1)
			printf("0 ");
		else if(A[i]==1 && B[j]==0)
			printf("1 ");
		else if(A[i]==0 && B[j]==1)
			printf("1 ");
		else if(A[i]==0 && B[j]==0)
			printf("0 ");
	}	
	return 0;
}