//Problem 18 : WAP to find prime numbers between an interveal of [a,b].
#include <stdio.h>
int main(){
	int a,b,count=0, i, j;
	printf("Enter range 1:");
	scanf("%d", &a);
	printf("Enter range 2:");
	scanf("%d", &b);
	printf("Prime numbers between the interveal of [%d,%d] :\n", a,b);
	for(i=a;i<=b;i++){
		count=0;
		for(j=2; j<=i/2;j++){
			if(i%j==0)
				count++;
		}
		if(count==0)
        printf("%d\n",i);
	}
	return 0;
}