//Problem 17 : WAP to find first nth prime where n is an integer.
#include <stdio.h>
int main(){
	
	int n,count=0, i, j;
	printf("Enter n:");
	scanf("%d", &n);
	printf("First %dth Prime numbers:\n", n);
	for(i=1;i<=n;i++){
		count=0;
		for(j=2; j<=i/2;j++){
			if(i%j==0)
				count++;
		}
		if(count==0)
        printf("%d\n",i);
	}
	return 0;
}